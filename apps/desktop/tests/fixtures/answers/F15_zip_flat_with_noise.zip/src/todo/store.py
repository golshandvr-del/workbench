from __future__ import annotations

import json
import os
from dataclasses import asdict
from pathlib import Path

from .model import Todo


class TodoStore:
    """Todos in one JSON file, saved atomically."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.items: list[Todo] = []
        if self.path.exists():
            self.items = [Todo(**x) for x in json.loads(self.path.read_text(encoding="utf-8"))]

    def add(self, title: str) -> Todo:
        t = Todo(title)
        self.items.append(t)
        self.save()
        return t

    def complete(self, todo_id: str) -> None:
        next(t for t in self.items if t.id == todo_id).done = True
        self.save()

    def remove(self, todo_id: str) -> None:
        self.items = [t for t in self.items if t.id != todo_id]
        self.save()

    def save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps([asdict(t) for t in self.items], indent=2), encoding="utf-8")
        os.replace(tmp, self.path)
