from __future__ import annotations

from dataclasses import dataclass, field
import uuid


@dataclass
class Todo:
    title: str
    done: bool = False
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
